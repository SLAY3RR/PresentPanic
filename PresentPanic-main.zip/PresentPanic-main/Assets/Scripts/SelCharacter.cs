using System;
using UnityEngine;
[Serializable]
public class SelCharacter 
{
    public GameObject prefab;
    public string name;
    public Sprite icon;
}
